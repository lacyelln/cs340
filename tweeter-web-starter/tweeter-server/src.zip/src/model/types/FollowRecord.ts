export interface FollowRecord {
    follower_handle: string;
    followee_handle: string;
}