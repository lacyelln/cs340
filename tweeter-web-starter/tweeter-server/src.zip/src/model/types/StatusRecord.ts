export interface StatusRecord {
  alias: string;
  post: string;
  timestamp: number;
}