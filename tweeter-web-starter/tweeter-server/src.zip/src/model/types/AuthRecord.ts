export interface AuthRecord {
    token: string;
    userAlias: string;
    timestamp: number;
}