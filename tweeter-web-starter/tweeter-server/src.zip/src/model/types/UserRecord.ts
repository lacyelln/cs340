export interface UserRecord {
  alias: string;
  firstName: string;
  lastName: string;
  imageUrl: string;
  hashedPassword: string;
}